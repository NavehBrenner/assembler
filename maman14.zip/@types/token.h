#include "constants.h"

#ifndef TOKEN_H
#define TOKEN_H

typedef struct tokenNode
{
  int type;
  char str[MAXSYMBOLLEN];
  struct tokenNode *next;
} tokenNode;

int getRegisterNum(char *str);
int extractNumber(char *str);
void freeTokenList(tokenNode *head);
int isValidNumber(char *str);
int isRegister(char *str);
int isRegisterPointer(char *str);
int isOperator(char *str);
int isLable(char *str);
int isInstruction(char *str);
int isSymbol(char *str);
int assignType(tokenNode *tok);

#define MACRO 1
#define END_MACRO 2
#define COMMENT 3
#define STRING 4
#define DATA_NUMBER 5
#define IMMIDIATE_NUMBER 6
#define OPCODE 7
#define REGISTER 8
#define REGISTER_PTR 9
#define SYMBOL 10
#define INSTRUCTION 11
#define COMMA 12
#define LABLE 13
#define NEWLINE 14
#define INVALID 0

#define MAX_LABLE_LEN 31
#define OPERATORS                                                                                                   \
  {                                                                                                                 \
    "mov", "cmp", "add", "sub", "lea", "clr", "not", "inc", "dec", "jmp", "bne", "red", "prn", "jsr", "rts", "stop" \
  }

#define INSTRUCTIONS_ARR                    \
  {                                         \
    ".data", ".string", ".extern", ".entry" \
  }
#define NO_OF_INSTRUCTIONS 4
#define NO_OF_OPERATORS 16
#endif