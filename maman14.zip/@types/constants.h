#ifndef CONSTANTS_H
#define CONSTANTS_H

#define MAXLINELEN 80
#define MAXSYMBOLLEN 31

#endif